# Тестовое задание на должность "Web-разработчик" для компании Space-Free. ⚡   

Цель: Сверстать макет и сделать функциональными блоки через админку.   
[Макет здесь](https://drive.google.com/file/d/16HQOu3hg8LBlw2IV5Oai_T5nLWxUoVxA/view)   🔗

## Порядок запуска проекта:   
1. Установить Wordpress (Не ниже версии 3.7.1)   
2. Разархивировать архив test-valo.zip и test-valo-plugins.zip.   
3. В директорию wordpress/wp-content/themes/ положить папку test-valo.    
4. В директорию wordpress/wp-content/plugins/ положить папку test-valo-plugins.   
5. Через phpMyAdmin или консоль загрузить **базу данных** из директории db/14022025.sql.   
6. Запустить сайт через https://localhost/.   

Войти в админку можно со ***следующими данными***:   
**Логин:** jkenix   
**Пароль:** dyb7YDL9bUL)*%rIg*   