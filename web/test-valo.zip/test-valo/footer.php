<?php get_template_part('templates/btn-top'); ?>

<?php wp_footer(); ?>

</body>

</html>