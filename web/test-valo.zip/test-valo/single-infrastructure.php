<?php get_header(); ?>

<div class="container main-pad-container container-404">

    <div class="row">
        <div class="col-12 mx-auto main-wrap">
            <p style="padding-top: 25px;font-size: 1.25rem; text-align: center; color: red;">Здесь мог бы быть контент, но он не включен в ТЗ. 😉</p>
            <p style="padding-top: 25px;font-size: 1.25rem; text-align: center;">Чтобы перейти в нужный раздел перейдите на <a href="/" class="txt-blue__w">главную станицу</a> или воспользуйтесь меню.</p>
        </div>
    </div>

</div>

<?php get_footer(); ?>